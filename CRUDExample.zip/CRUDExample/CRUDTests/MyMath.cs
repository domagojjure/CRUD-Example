﻿using System;
namespace CRUDTests
{
	public class MyMath
	{
		public int Add(int a, int b)
		{
			int c = a + b;
			return c;
		}
	}
}

