﻿using System;
using ServiceContracts;
using Entities;
using Services;
using ServiceContracts.DTO;

namespace CRUDTests
{
    public class CountriesServiceTest
    {
        private readonly ICountriesService _countriesService;

        public CountriesServiceTest()
        {
            _countriesService = new CountriesService(false);

        }
        #region AddCountry
        //When you supply null, it should throw ArgumentNullException
        [Fact]
        public void AddCountry_NullCountry()
        {
            //Arrange
            CountryAddRequest? request = null;

            //Assert
            Assert.Throws<ArgumentNullException>(() =>
            {
                //Act
                _countriesService.AddCountry(request);
            });
        }
        //When CountryName is null it should throw ARgumentException
        [Fact]
        public void AddCountry_NullCountryIsNull()
        {
            //Arrange
            CountryAddRequest? request = new CountryAddRequest() { CountryName = null };

            //Assert
            Assert.Throws<ArgumentException>(() =>
            {
                //Act
                _countriesService.AddCountry(request);
            });
        }
        //When CountryName is duplicate it should throw ArgumentException
        [Fact]
        public void AddCountry_DuplicateCountryName()
        {
            //Arrange
            CountryAddRequest? request = new CountryAddRequest() { CountryName = "USA" };
            CountryAddRequest? request2 = new CountryAddRequest() { CountryName = "USA" };


            //Assert
            Assert.Throws<ArgumentException>(() =>
            {
                //Act
                _countriesService.AddCountry(request);
                _countriesService.AddCountry(request2);

            });
        }

        //When you supply proper country name it should insert it to the existing list of countries
        [Fact]
        public void AddCountry_ProperCountryDetails()
        {
            //Arrange
            CountryAddRequest? request = new CountryAddRequest() { CountryName = "Japan" };

            //Act
            CountryResponse response = _countriesService.AddCountry(request);
            List<CountryResponse> countries_from_get_all_countries = _countriesService.GetAllCountries();
            //Assert
            Assert.True(response.CountryID != Guid.Empty);
            Assert.Contains(response, countries_from_get_all_countries);


        }
        #endregion

        #region GetAllCountries
        [Fact]
        //The list of countries should be empty by default (before adding any countries)
        public void GetAllCoutries_EmptyList()
        {
            //Act
            List<CountryResponse> countries_list = _countriesService.GetAllCountries();

            //Assert
            Assert.Empty(countries_list);
        }

        [Fact]
        public void GetAllCountries_AddFewCountries()
        {
            //Arrange
            List<CountryAddRequest> country_request_list = new List<CountryAddRequest>() { new CountryAddRequest() { CountryName = "USA" }, new CountryAddRequest() { CountryName = "Japan" } };

            //Act
            List<CountryResponse> added_countries = new List<CountryResponse>();
            foreach (CountryAddRequest country_request in country_request_list)
            {
                added_countries.Add(_countriesService.AddCountry(country_request));
            }

            List<CountryResponse> actualCountryResponseList = _countriesService.GetAllCountries();

            foreach (CountryResponse expected_country in added_countries)
            {
                Assert.Contains(expected_country, actualCountryResponseList);
            }
        }





        #endregion

        #region GetCountryByID
        [Fact]
        public void GetCountryByID_NullCountryID()
        {
            //Arrange
            Guid? id = null;
            //Act
            CountryResponse? country_response_ByID = _countriesService.GetCountryByID(id);
            //Assert
            Assert.Null(country_response_ByID);
        }
        //if we supply a valid country id, return the corresponding country
        [Fact]
        public void GetCountryByID_ValidID()
        {
            //Arrange
            CountryAddRequest? country_add_request = new CountryAddRequest() { CountryName = "China" };
            CountryResponse country_response_fromAdd =
            _countriesService.AddCountry(country_add_request);

            //Act
            CountryResponse? country_response_from_get = _countriesService.GetCountryByID(country_response_fromAdd.CountryID);
            //Assert
            Assert.Equal(country_response_fromAdd, country_response_from_get);
        }
        #endregion
    }
}

