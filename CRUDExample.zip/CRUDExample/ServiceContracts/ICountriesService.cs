﻿namespace ServiceContracts;
using DTO;
public interface ICountriesService
{
    /// <summary>
    /// adds a cuntry object to the list of countries
    /// </summary>
    /// <param name="countryAddRequest"></param>
    /// <returns>returns the country object after adding it </returns>
    CountryResponse AddCountry(CountryAddRequest? countryAddRequest);

    List<CountryResponse> GetAllCountries();

    /// <summary>
    /// Returns Country object based on countryID
    /// </summary>
    /// <param name="CountryID"></param>
    /// <returns>MAtching country object</returns>
    CountryResponse? GetCountryByID(Guid? CountryID);


}

