﻿using System;
using ServiceContracts.Enums;
using Entities;
using System.ComponentModel.DataAnnotations;
namespace ServiceContracts.DTO
{
    /// <summary>
    /// acts as a dto 
    /// </summary>
    public class PersonAddRequest
    {
        [Required(ErrorMessage = "PersonName can't be blank")]
        public string? PersonName { get; set; }
        [Required(ErrorMessage = "Email cant be blank")]
        [EmailAddress(ErrorMessage = "this has to be an email address")]
        [DataType(DataType.EmailAddress)]
        public string? Email { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public GenderOptions? Gender { get; set; }
        public Guid? CountryID { get; set; }
        public string? Address { get; set; }
        public bool ReceiveNewsLetters { get; set; }

        /// <summary>
        /// Converts the current object of PersonAddRequest into a new Person object
        /// </summary>
        /// <returns></returns>
        public Person toPerson()
        {
            return new Person() { PersonName = this.PersonName, Email = this.Email, DateOfBirth = this.DateOfBirth, Gender = this.Gender.ToString(), Address = this.Address, CountryID = this.CountryID, ReceiveNewsLetters = this.ReceiveNewsLetters };
        }
    }
}

