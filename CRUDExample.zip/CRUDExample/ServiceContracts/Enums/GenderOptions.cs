﻿using System;
namespace ServiceContracts.Enums
{
    public enum GenderOptions
    {
        Male, Female
    }
}

