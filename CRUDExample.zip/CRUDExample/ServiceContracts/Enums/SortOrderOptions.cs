﻿using System;
namespace ServiceContracts.Enums
{
    public enum SortOrderOptions
    {
        ASC, DESC
    }
}

